
This is a sample Python package created for Exercise 09 in Python_00. It contains a function `count_in_list` that counts occurrences of an item in a list.
